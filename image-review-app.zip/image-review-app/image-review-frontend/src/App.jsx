import UploadForm from "./components/UploadForm";

function App() {
  return (
    <div>
      <UploadForm />
    </div>
  );
}

export default App;
